//
//  GameViewController.swift
//  2DImageIn3DWorld
//
//  Created by xsf on 2018/3/8.
//  Copyright © 2018年 xsf. All rights reserved.
//

import UIKit
import QuartzCore
import SceneKit
//import SpriteKit

public class GameViewControllerTwo: UIViewController {
    var ARButton : UIButton!
    public var gameSCNView : GameSCNViewTwo!
    override public func viewDidLoad() {
        super.viewDidLoad()
        gameSCNView = GameSCNViewTwo(frame:CGRect(x: 0, y: 0, width: 520, height: 800))
        self.view.addSubview(gameSCNView)
        //跳转的button
        ARButton = UIButton(frame: CGRect(x: 210, y: 30, width: 100, height: 100))
        ARButton.setBackgroundImage(UIImage(named: "ARBtn.png"), for: .normal)
        ARButton.addTarget(self, action: #selector(goToAR), for: .touchUpInside)
        self.view.addSubview(ARButton)
    }
    @objc func goToAR(){
        let model = gameSCNView.scene?.rootNode.childNode(withName: "china", recursively: true)
        let nextViewController = ARViewControllerTwo()
        nextViewController.ThisNode = model!
        self.present(nextViewController, animated: true, completion: nil)
    }
    override public var shouldAutorotate: Bool {
        return true
    }
    
    override public var prefersStatusBarHidden: Bool {
        return true
    }
    
    override public var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }

}
