//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SceneKit
import PlaygroundSupport

public class GameSCNViewOne: SCNView {
    var spriteScene : GameSceneOne!
    public var customizeModel : SCNNode!
    var currentTapNode : SCNNode!
    override public init(frame: CGRect, options: [String : Any]? = nil) {
        super.init(frame: frame, options: nil)
        //背景音乐
        playBackgroundMusic(fileName:"background.m4a",loops:-1)
        spriteScene = GameSceneOne(size: frame.size, scnView: self)
        // create a new scene
        let scene = SCNScene(named: "zfx1Before.scn")!
        
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .directional
        lightNode.light?.intensity = 1200
        lightNode.position = SCNVector3(x: 0, y: 0, z: 0)
        cameraNode.addChildNode(lightNode)
        
        //相机大小
        cameraNode.camera?.fieldOfView = 20
        // retrieve the ship node
        customizeModel = scene.rootNode.childNode(withName: "china", recursively: true)!
        customizeModel.position.x += 0.5
        customizeModel.name = "china"
        // animate the 3d object
        customizeModel.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 1)))
        
        //添加spriteNode到SCN
        self.overlaySKScene = spriteScene
        
        // set the scene to the view
        self.scene = scene
        
        // allows the user to manipulate the camera
        self.allowsCameraControl = false
        
        // configure the view
        self.backgroundColor = UIColor(white: 1.0, alpha: 0.5)
        
        // add a tap gesture recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        self.addGestureRecognizer(tapGesture)
        //默认被贴的部分
        currentTapNode = customizeModel.childNode(withName: "top", recursively: true)
        //正确移动桌子的位置
        let dz = scene.rootNode.childNode(withName: "网格01", recursively: true)!
        dz.position.x += 0.5
    }
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        spriteScene.isUserInteractionEnabled = true
        // check what nodes are tapped
        let p = gestureRecognize.location(in: self)
        let hitResults = self.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            // get its material
            let material = result.node.geometry!.firstMaterial!
            currentTapNode = result.node
            //判断被点击的node
            if currentTapNode.name == "top"{
                spriteScene.rotateNode.removeAllChildren()
                spriteScene.addSprites(Index: 0)
            }else if currentTapNode.name == "middle"{
                spriteScene.rotateNode.removeAllChildren()
                spriteScene.addSprites(Index: 1)
            }else if currentTapNode.name == "bottom"{
                spriteScene.rotateNode.removeAllChildren()
                spriteScene.addSprites(Index: 2)
            }else if currentTapNode.name == "网格01"{
                return
            }
            // highlight it
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                
                material.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            material.emission.contents = UIColor.red
            
            SCNTransaction.commit()
        }
        
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
