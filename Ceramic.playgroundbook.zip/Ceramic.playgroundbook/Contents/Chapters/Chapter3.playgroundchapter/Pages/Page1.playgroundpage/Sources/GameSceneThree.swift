//
//  GameScene.swift
//  2DImageIn3DWorld
//
//  Created by xsf on 2018/3/9.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SpriteKit
import GameplayKit

public class GameSceneThree : SKScene{
    var square0 = SKSpriteNode()
    var square1 = SKSpriteNode()
    var square2 = SKSpriteNode()
    var square3 = SKSpriteNode()
    var squares : [SKSpriteNode]!
    let radius : CGFloat = 150
    let turnSpeed : Double = 0.5
    var centerPoint : CGPoint!
    var currentTapModelPart : SCNNode!
    
    var bezierPath0 = UIBezierPath()
    var bezierPath1 = UIBezierPath()
    var bezierPath2 = UIBezierPath()
    var bezierPath3 = UIBezierPath()
    var downPaths : [UIBezierPath]!
    
    var bezierPath4 = UIBezierPath()
    var bezierPath5 = UIBezierPath()
    var bezierPath6 = UIBezierPath()
    var bezierPath7 = UIBezierPath()
    var upPaths : [UIBezierPath]!
    
    var touchFirst : CGPoint!
    var touchLast : CGPoint!
    var touchOver : Bool = false
    //    var game:GameViewController!
    var scnView : GameSCNViewThree!
    
    var totalImages = [["regular2.jpg","top2.jpg","regular2.jpg","regular3.jpg"],["regular4.jpg","regular2.jpg","regular3.jpg","regular1.jpg"],["regular4.jpg","regular3.jpg","regular5.jpg","regular6.JPG"]]
    var currentImages : [String] = []
    var rotateNode = SKNode()
    init(size: CGSize,scnView : GameSCNViewThree){
        super.init(size: size)
        //确定中心点
        centerPoint = CGPoint(x: 0, y: self.size.height/2)
        //转盘的父节点
        addChild(rotateNode)
        //添加精灵
        addSprites(Index:0)
        //定义好上和下的路径
        downPaths = [bezierPath0,bezierPath1,bezierPath2,bezierPath3]
        for i in 0...(downPaths.count-1){
            downPaths[i] = UIBezierPath(arcCenter: centerPoint, radius: radius, startAngle: CGFloat(-Double.pi/2)*CGFloat(i), endAngle: CGFloat(-Double.pi/2)*CGFloat(i+1), clockwise: false)
        }
        upPaths = [bezierPath4,bezierPath5,bezierPath6,bezierPath7]
        for i in 0...(upPaths.count-1){
            upPaths[i] = UIBezierPath(arcCenter: centerPoint, radius: radius, startAngle: CGFloat(Double.pi/2)*CGFloat(4-i), endAngle: CGFloat(Double.pi/2)*CGFloat(5-i), clockwise: true)
        }
        self.scnView = scnView
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addSprites(Index:Int){
        squares = [square0,square1,square2,square3]
        //显示相应的image贴图
        currentImages = totalImages[Index]
        for i in 0...(squares.count-1){
//            squares[i] = SKSpriteNode(texture: SKTexture(imageNamed: currentImages[i]), size: CGSize(width: 60, height: 60))
            squares[i] = SpriteCorners(preImageName : currentImages[i],cornerRadius:90.0)
            squares[i].name = currentImages[i]
            rotateNode.addChild(squares[i])
        }
        spritePosition(sprites: squares, centerPosition: centerPoint, radius: radius)
    }
    func Down(){
        //播放转动音效
        playCategorySound(fileName:"gearStart.m4a",loops:0)
        self.isUserInteractionEnabled = false
        //asOffset表示以结点作为原点；orientToPath表示图形在运动过程中是否跟着路径旋转
        for i in 0...(squares.count-1){
            if i != squares.count-1{
                squares[i].run(SKAction.follow(downPaths[i].cgPath, asOffset: false, orientToPath: false, duration: turnSpeed)){
                    self.isUserInteractionEnabled = true
                }
            }else{
                //转完之后数组重新排序
                squares[i].run(SKAction.follow(downPaths[i].cgPath, asOffset: false, orientToPath: false, duration: turnSpeed)){
                    let lastSquare = self.squares[i]
                    self.squares.insert(lastSquare, at: 0)
                    self.squares.removeLast()
                    self.isUserInteractionEnabled = true
                }
            }
        }
    }
    func Up(){
        //播放转动音效
        playCategorySound(fileName:"gearStart.m4a",loops:0)
        //asOffset表示以结点作为原点；orientToPath表示图形在运动过程中是否跟着路径旋转
        for i in 0...(squares.count-1){
            self.isUserInteractionEnabled = false
            if i != squares.count-1{
                squares[i].run(SKAction.follow(upPaths[i].cgPath, asOffset: false, orientToPath: false, duration: turnSpeed)){
                    self.isUserInteractionEnabled = true
                }
            }else{
                //转完之后数组重新排序
                squares[i].run(SKAction.follow(upPaths[i].cgPath, asOffset: false, orientToPath: false, duration: turnSpeed)){
                    let firstSquare = self.squares[0]
                    self.squares.append(firstSquare)
                    self.squares.remove(at: 0)
                    self.isUserInteractionEnabled = true
                }
            }
        }
    }
    //利用touchesBegan判断手势，判断touch的位置
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //开始触摸
        touchOver = false
        guard let touch=touches.first else{
            return
        }
        let location=touch.location(in: self)
        for i in 0...(squares.count-1){
            if self.atPoint(location).name==squares[i].name {
                //                tapImageName = squares[i].name!
                currentTapModelPart = scnView.currentTapNode
                //判断点击的部分
                if currentTapModelPart.name != "网格01"{
                    currentTapModelPart.geometry?.materials.first?.diffuse.contents = UIImage(named: squares[i].name!)
                    currentTapModelPart.geometry?.materials.first?.diffuse.wrapT = SCNWrapMode.repeat
                    currentTapModelPart.geometry?.materials.first?.diffuse.wrapS = SCNWrapMode.repeat
                    //播放添加纹理的音效
//                    playappearMusic(fileName:"spray.m4a",loops:0)
                }
                if i == 1{
                    self.Up()
                }
                if i == 3{
                    self.Down()
                }
            }
        }
    }
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if touchOver == false {
            for touch: AnyObject in touches {
                let t:UITouch = touch as! UITouch
                print("________")
                print(t.location(in: self.view))
                print(t.previousLocation(in: self.view))
                print("_________")
                //判断上滑还是下滑
                touchFirst = t.location(in: self.view)
                touchLast = t.previousLocation(in: self.view)
                if touchLast.y - touchFirst.y < 0{
                    self.Down()
                    touchOver = true
                }else if touchLast.y - touchFirst.y > 0{
                    self.Up()
                    touchOver = true
                }else if touchLast.y - touchFirst.y == 0{
                    
                }
            }
        }
    }
}

