//
//  ViewController.swift
//  ARTest
//
//  Created by xsf on 2018/3/18.
//  Copyright © 2018年 xsf. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

public class ARViewControllerOne: UIViewController, ARSCNViewDelegate {
    var sceneView: ARSCNView!
    //场景中的object数组
    var objects: [SCNNode] = []
    //显示环境信息的label
    var messageLabel : UILabel!
    var trackingInfo: UILabel!
    public var ThisNode = SCNNode()
    var planeNode = SCNNode()
    override public func viewDidLoad() {
        super.viewDidLoad()
        sceneView = ARSCNView(frame: self.view.frame)
        self.view.addSubview(sceneView)
        // Set the view's delegate
        sceneView.delegate = self
        // Create a new scene
        let scene = SCNScene(named: "customize.scn")!
        // Set the scene to the view
        sceneView.scene = scene
        //传递自定义的模型
        //显示环境信息的Label
        messageLabel = UILabel(frame: CGRect(x: 10, y: 10, width: 100, height: 50))
        self.view.addSubview(messageLabel)
        messageLabel.text = ""
        trackingInfo = UILabel(frame: CGRect(x: 150, y: 10, width: 100, height: 50))
        self.view.addSubview(trackingInfo)
        trackingInfo.text = ""
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        // 平面检测
        configuration.planeDetection = .horizontal
        // 现实光线检测
        configuration.isLightEstimationEnabled = true
        // Run the view's session
        sceneView.session.run(configuration)
        //显示特征点
        sceneView.debugOptions = ARSCNDebugOptions.showFeaturePoints
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    public func renderer(_ renderer: SCNSceneRenderer,didAdd node: SCNNode,for anchor: ARAnchor) {
        DispatchQueue.main.async {
            //识别平面的时候把平面渲染出来
            if let planeAnchor = anchor as? ARPlaneAnchor {
                self.planeNode = createPlaneNode(
                    center: planeAnchor.center,
                    extent: planeAnchor.extent)
                node.addChildNode(self.planeNode)
                
                //添加陶瓷模型
                self.ThisNode.scale = SCNVector3(x: 0.15, y: 0.15 ,z: 0.15)
                self.ThisNode.position = SCNVector3(planeAnchor.center.x, 0.12, planeAnchor.center.z)
                self.ThisNode.removeAllActions()
                node.addChildNode(self.ThisNode)
            }
        }
    }
    //检测的物体或者平面发生变化的时候触发的方法
    public func renderer(_ renderer: SCNSceneRenderer,didUpdate node: SCNNode,for anchor:ARAnchor){
        DispatchQueue.main.async {
            if let planeAnchor = anchor as? ARPlaneAnchor {
                updatePlaneNode(node.childNodes[0],center: planeAnchor.center,extent: planeAnchor.extent)
            }
        }
    }
    //平面被移除的时候触发的方法
    public func renderer(_ renderer: SCNSceneRenderer,didRemove node: SCNNode,for anchor:ARAnchor) {
        guard anchor is ARPlaneAnchor else { return }
        // 2
        removeChildren(inNode: node)
    }
    
    //hitTest
    override public func touchesBegan(_ touches: Set<UITouch>,with event: UIEvent?) {
        
    }
    
    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    // MARK: - ARSCNViewDelegate
    
    /*
     // Override to create and configure nodes for anchors added to the view's session.
     func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
     let node = SCNNode()
     
     return node
     }
     */
    
    public func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    public func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    public func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}

