//
//  Helper.swift
//  2DImageIn3DWorld
//
//  Created by xsf on 2018/3/9.
//  Copyright © 2018年 xsf. All rights reserved.
//

import Foundation
import SpriteKit
import SceneKit
import ARKit
//2D辅助函数
func plusPoint(left:CGPoint,right:CGPoint)->CGPoint{
    let plusPointer = CGPoint(x: left.x + right.x, y: left.y + right.y)
    return plusPointer
}
func spritePosition(sprites:[SKSpriteNode],centerPosition:CGPoint,radius:CGFloat){
    for i in 0...(sprites.count-1){
        let additionPosition = CGPoint(x: cos(CGFloat(Double.pi/2)*CGFloat(i))*radius, y: -sin(CGFloat(Double.pi/2)*CGFloat(i))*radius)
        sprites[i].position = plusPoint(left: centerPosition, right: additionPosition)
    }
}
//3D辅助函数
func nodeWithModelName(_ modelName: String) -> SCNNode {
    return SCNScene(named: modelName)!.rootNode.clone()
}

func createPlaneNode(center: vector_float3, extent: vector_float3) -> SCNNode {
    let plane = SCNPlane(width: CGFloat(extent.x), height: CGFloat(extent.z))
    
    let planeMaterial = SCNMaterial()
//    planeMaterial.diffuse.contents = UIColor.blue.withAlphaComponent(0.4)
    planeMaterial.diffuse.contents = UIColor(white: 1.0, alpha: 0)
    plane.materials = [planeMaterial]
    let planeNode = SCNNode(geometry: plane)
    planeNode.position = SCNVector3Make(center.x, 0, center.z)
    planeNode.transform = SCNMatrix4MakeRotation(-Float.pi / 2, 1, 0, 0)
    
    return planeNode
}

func updatePlaneNode(_ node: SCNNode, center: vector_float3, extent: vector_float3) {
    let geometry = node.geometry as! SCNPlane
    
    geometry.width = CGFloat(extent.x)
    geometry.height = CGFloat(extent.z)
    node.position = SCNVector3Make(center.x, 0, center.z)
}

func removeChildren(inNode node: SCNNode) {
    for node in node.childNodes {
        node.removeFromParentNode()
    }
}

func createSphereNode(radius: CGFloat) -> SCNNode {
    let sphere = SCNSphere(radius:radius)
    sphere.firstMaterial?.diffuse.contents = UIColor.red
    return SCNNode(geometry: sphere)
}

func createLineNode(fromNode: SCNNode, toNode: SCNNode) -> SCNNode {
    let line = lineFrom(vector: fromNode.position, toVector: toNode.position)
    let lineNode = SCNNode(geometry: line)
    let planeMaterial = SCNMaterial()
    planeMaterial.diffuse.contents = UIColor.red
    line.materials = [planeMaterial]
    return lineNode
}

func lineFrom(vector vector1: SCNVector3, toVector vector2: SCNVector3) -> SCNGeometry {
    let indices: [Int32] = [0, 1]
    
    let source = SCNGeometrySource(vertices: [vector1, vector2])
    let element = SCNGeometryElement(indices: indices, primitiveType: .line)
    
    return SCNGeometry(sources: [source], elements: [element])
}
//UIViewController的辅助函数
extension UIViewController {
    var viewCenter: CGPoint {
    let screenSize = view.bounds
    return CGPoint(x: screenSize.width / 2.0, y: screenSize.height / 2.0)
}

func showMessage(_ message: String, label: UILabel, seconds: Double) {
    label.text = message
    
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
        if label.text == message {
            label.text = ""
        }
    }
}
}

//SKSpriteNode圆角
func SpriteCorners(preImageName : String,cornerRadius : CGFloat)->SKSpriteNode{
    let preImage = UIImage(named: preImageName)!
//    preImage.size = CGSize(width:cornerRadius*2,height:cornerRadius*2)
    UIGraphicsBeginImageContextWithOptions(preImage.size, false, 0)
    //变成正方形
    let rect = CGRect(x: 0, y: 0, width: preImage.size.width, height: preImage.size.height)
    UIBezierPath(roundedRect: rect, cornerRadius: preImage.size.height).addClip()
    preImage.draw(in: rect)
    
    let roundImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    let texture = SKTexture(image: roundImage!)
    let cornerNode = SKSpriteNode(texture: texture, size: CGSize(width: cornerRadius, height: cornerRadius))
    return cornerNode
}


