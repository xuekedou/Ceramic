/*:
 # 🎉Congratulations on coming to the last page. Here, you can [create](glossary://create) the
 ceramic you like and put it in the [real world](glossary:real%20world)!
 * [Click on](glossary://Click%20on) different parts of the ceramic to get [different candidate
 texture groups](glossary://different%20candidate%20texture%20groups)
 * Preview texture thumbnails with [swipe gestures](glossary://swipe%20gestures), and see the
 effect by [clicking](glossary://click) on your favorite texture image.
 * Through the [code](glossary://code) select different ceramic models, with
 different textures, to create your favorite ceramic
 * Click the [AR button](glossary://AR%20button) to put the custom ceramic into the
 real world
 * [Note](glossary://Note):Only when you detect the plane in the real world can you place a ceramic model in the real world. Don't put your own ceramics in the air, it will break.
 # Alternative models：
 * [ModelOne](glossary://ModelOne)
 * [ModelTwo](glossary://ModelTwo)
 * [ModelThree](glossary://ModelThree)
 * [ModelFour](glossary://ModelFour)

 [Ceramics is not only an item but also an art.](glossary://Ceramics%20is%20not%20only%20an%20item%20but%20also%20an%20art.) I do hope you will enjoy
 ceramics by experiencing this Swift Playgrounds Book.Thank you~
 */
//#-hidden-code
import SceneKit
import GameplayKit
import PlaygroundSupport

let ModelOne = GameViewController()
let ModelTwo = GameViewControllerOne()
let ModelThree = GameViewControllerTwo()
let ModelFour = GameViewControllerThree()
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, ModelOne, ModelTwo, ModelThree, ModelFour)
//Change the Model prepared to Customize
PlaygroundPage.current.liveView =
/*#-editable-code*/ModelOne/*#-end-editable-code*/




