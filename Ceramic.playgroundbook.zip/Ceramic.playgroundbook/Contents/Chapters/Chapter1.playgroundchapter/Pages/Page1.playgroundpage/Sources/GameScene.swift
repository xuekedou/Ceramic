//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SpriteKit
import GameplayKit

public class GameScene : SKScene{
    public var textLabel : SKLabelNode!
    var textNode : SKSpriteNode!
    var textContent = ""
    override init(size: CGSize){
        super.init(size: size)
        textNode = SKSpriteNode(color: UIColor(white: 1, alpha: 0), size: CGSize(width: 260, height: size.height/2))
        textNode.position = CGPoint(x: size.width/4*3, y: size.height/2)
        textLabel = SKLabelNode(text:"Ceramic is the general \nname of pottery and \nporcelain.Pottery \nvessels made of clay \nare called pottery,\nand pottery vessels \nmade of clay are \ncalled porcelain.")
        textLabel.numberOfLines = 0
        textLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        textLabel.fontName = "AppleSDGothicNeo-UltraLight"
        textLabel.fontSize = 15
        textLabel.fontColor = UIColor.white
        textLabel.position = CGPoint(x: 0, y: -textNode.frame.size.height/3)
        
        textNode.addChild(textLabel)
        addChild(textNode)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
