/*:
 # Welcome to "Ceramics"! In this page,you will learn about the most basic knowledge of ceramics and lay the groundwork for a better experience of ceramics.
 
 * The interface uses 3D model with brief text to introduce ceramics
 * [Tap on the 3D model](glossary://Tap%20on%20the%203D%20model) will allow you to observe it more meticulously and more comprehensively, helping you to better understand the content of
   the text.
 * You can change the [background style](glossary://background%20style) to get a different experience.

 # Available background styles：
 * [conciseBackground](glossary://conciseBackground)
 * [ThreeDimensionalDBackground](glossary://ThreeDimensionalDBackground)
 
 🎉 Great! you now have a basic knowledge of ceramics. Next you will learn about the [process of making ceramics](glossary://process%20of%20making%20ceramics)!
 */
//#-hidden-code
import SceneKit
import GameplayKit
import PlaygroundSupport
let conciseBackground = GameSCNView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let ThreeDimensionalDBackground = GameSCNViewOne(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, conciseBackground, ThreeDimensionalDBackground)
//Chang the background style
PlaygroundPage.current.liveView =
/*#-editable-code*/conciseBackground/*#-end-editable-code*/










