/*:
 # In this page, you will understand the magical and gorgeous transformation from plain clay to exquisite ceramics.

 * The interface uses 3D models with [animations](glossary://animations) and brief texts to
   introduce them.
 * [Clicking on the 3D model](glossary://Clicking%20on%20the%203D%20model) allows you to observe it more meticulously and more comprehensively, helping you to gain a deeper understanding of the [morphological characteristics](glossary://morphological%20characteristics) of ceramics in each production step.
 * You can change the [background style](glossary://background%20style) to get a different
   experience.
 # Available background styles：
 * [conciseBackground](glossary://conciseBackground)
 * [ThreeDimensionalDBackground](glossary://ThreeDimensionalDBackground)
 
 🎉 Great! You now have a basic understanding of ceramics. Next you will learn more about
   ceramics from [multiple dimensions](glossary://multiple%20dimensions) in an [interactive way](glossary://interactive%20way).
 */
//#-hidden-code
import SceneKit
import GameplayKit
import PlaygroundSupport

let conciseBackground = GameSCNView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let ThreeDimensionalDBackground = GameSCNViewOne(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, conciseBackground, ThreeDimensionalDBackground)
//Change the background style
PlaygroundPage.current.liveView =
    /*#-editable-code*/conciseBackground/*#-end-editable-code*/




