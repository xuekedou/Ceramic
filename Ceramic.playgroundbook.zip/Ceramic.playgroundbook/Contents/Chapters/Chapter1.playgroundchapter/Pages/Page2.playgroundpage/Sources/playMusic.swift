//
//  playMusic.swift
//  SoundDiff
//
//  Created by xsf on 2018/3/20.
//  Copyright © 2018年 xsf. All rights reserved.
//

import Foundation
import AVFoundation

var backgroundMusicPlayer : AVAudioPlayer!
//星星音效播放器
var appearMusic : AVAudioPlayer!
var flipMusic : AVAudioPlayer!
//火焰播放器
public var categoryMusic : AVAudioPlayer!
public func playCategorySound(fileName:String,loops:Int){
    let resourceUrl = Bundle.main.url(forResource: fileName, withExtension: nil)
    guard let url = resourceUrl else {
        print("Could not find file: \(fileName)")
        return
    }
    do {
        try categoryMusic = AVAudioPlayer(contentsOf: url)
        categoryMusic.numberOfLoops = loops
        categoryMusic.prepareToPlay()
        categoryMusic.play()
    }catch {
        print("Could not create audio player!")
        return
    }
}
//background music
public func playBackgroundMusic(fileName:String,loops:Int){
    let resourceUrl = Bundle.main.url(forResource: fileName, withExtension: nil)
    guard let url = resourceUrl else {
        print("Could not find file: \(fileName)")
        return
    }
    do {
        try backgroundMusicPlayer = AVAudioPlayer(contentsOf: url)
        backgroundMusicPlayer.numberOfLoops = loops
        backgroundMusicPlayer.prepareToPlay()
        backgroundMusicPlayer.play()
    }catch {
        print("Could not create audio player!")
        return
    }
}
//music
public func playappearMusic(fileName:String,loops:Int){
    let resourceUrl = Bundle.main.url(forResource: fileName, withExtension: nil)
    guard let url = resourceUrl else {
        print("Could not find file: \(fileName)")
        return
    }
    do {
        try appearMusic = AVAudioPlayer(contentsOf: url)
        appearMusic.numberOfLoops = loops
        appearMusic.prepareToPlay()
        appearMusic.play()
    }catch {
        print("Could not create audio player!")
        return
    }
}
//
public func playFlipMusic(fileName:String,loops:Int){
    let resourceUrl = Bundle.main.url(forResource: fileName, withExtension: nil)
    guard let url = resourceUrl else {
        print("Could not find file: \(fileName)")
        return
    }
    do {
        try flipMusic = AVAudioPlayer(contentsOf: url)
        flipMusic.numberOfLoops = loops
        flipMusic.prepareToPlay()
        flipMusic.play()
    }catch {
        print("Could not create audio player!")
        return
    }
}



