//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SceneKit
import SpriteKit
import PlaygroundSupport

public class GameSCNViewOne: SCNView {
    var lastHeightRatio: Float = 0
    var lastHeightRatioTest : Float = 0
    var lastWidthRatioTest : Float = 0
    var resetRatio : Float = 0
    let resetAngle : [Float] = [-7.0/8,-5.0/8,-3.0/8,-1.0/8,1.0/8,3.0/8,5.0/8,7.0/8]
    let camera = SCNCamera()
    let cameraNode = SCNNode()
    let cameraOrbit = SCNNode()
    //四个模型
    var box = SCNNode()
    var cylinder = SCNNode()
    var pyramid = SCNNode()
    var sphere = SCNNode()
    var root = SCNNode()
    //火焰的粒子效果
    var fire : SCNParticleSystem!
    var fireNode : SCNNode!
    var isFire = false
    //完成的庆祝效果
    var star : SCNParticleSystem!
    var starNode : SCNNode!
    var isStar = false
    //右边的简介
    var textScene : GameScene!
    //空白的scene
    var blankScene = SKScene()
    //呈现的SCNScene
    public var scnScene = SCNScene()
    //test场景的镜头
    let cameraNodeTest = SCNNode()
    let cameraTest = SCNCamera()
    let cameraOrbitTest = SCNNode()
    //test.scn场景
    var testScn = SCNScene()
    var placeNode = SCNNode()
    var isShowModel : Bool = false
    //两个手势
    var PanGesture = UIPanGestureRecognizer()
    var tapGesture = UITapGestureRecognizer()
    //现在显示的模型
    var currentNode = SCNNode()
    //是否第一次显示
    var isFirstLoad : Bool = true
    override public init(frame: CGRect, options: [String : Any]? = nil) {
        super.init(frame: frame, options: nil)
        //test.scn
        testScn = SCNScene(named: "TestOne.scn")!
        placeNode = testScn.rootNode.childNode(withName: "place", recursively: true)!
        //初始化文字视图
        textScene = GameScene(size: frame.size)
        //        self.overlaySKScene = textScene
        //火焰的粒子效果
        fireNode = SCNNode()
        fire = SCNParticleSystem(named: "hot.scnp", inDirectory: nil)!
        fire.particleSize = 1
        fireNode.addParticleSystem(fire)
        fireNode.position = SCNVector3(x: 0, y: -1, z: 0.2)
        //庆祝粒子效果
        starNode = SCNNode()
        star = SCNParticleSystem(named: "start.scnp", inDirectory: nil)!
        starNode.addParticleSystem(star)
        starNode.position = SCNVector3(x: -4, y: 0, z: 0)
        starNode.name = "star"
        //背景音乐
        playBackgroundMusic(fileName:"background.m4a",loops:-1)
        // create a new scene
        scnScene = SCNScene(named: "Introduction1.scn")!
        //(2,0,0)
        box = SCNScene(named: "1Original.scn")!.rootNode.childNode(withName: "china", recursively: true)!
        cylinder = SCNScene(named: "qhc1.scn")!.rootNode.childNode(withName: "china", recursively: true)!
        pyramid = SCNScene(named: "qhc1.scn")!.rootNode.childNode(withName: "china", recursively: true)!
        sphere = SCNScene(named: "1.scn")!.rootNode.childNode(withName: "china", recursively: true)!
        //默认显示Node
        currentNode = box
        //右边介绍的占位节点
        root = scnScene.rootNode.childNode(withName: "model", recursively: true)!
        // place the camera
        cameraNode.position = SCNVector3(x: 0.5, y: 0, z: 10)
        //camera背景模糊 depth of field
        camera.fieldOfView = 45.0
        cameraNode.camera = camera
        
        //旋转的轨道Node
        cameraOrbit.addChildNode(cameraNode)
        scnScene.rootNode.addChildNode(cameraOrbit)
        //test场景
        cameraNodeTest.position = SCNVector3(x: 0, y: 0, z: 3)
        cameraNodeTest.camera = cameraTest
        cameraTest.fieldOfView = 45.0
        cameraOrbitTest.addChildNode(cameraNodeTest)
        testScn.rootNode.addChildNode(cameraOrbitTest)
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .directional
        lightNode.light?.intensity = 1200
        lightNode.position = SCNVector3(x: 0, y: 0, z: 0)
        cameraNode.addChildNode(lightNode)
        
        let lightNodeTest = SCNNode()
        lightNodeTest.light = SCNLight()
        lightNodeTest.light!.type = .directional
        lightNodeTest.light?.intensity = 1150
        lightNodeTest.position = SCNVector3(x: 0, y: 0, z: 0)
        cameraNodeTest.addChildNode(lightNodeTest)
        // set the scene to the view
        //        self.scene = scnScene
        
        // add a tap gesture recognizer
        PanGesture = UIPanGestureRecognizer(target: self, action:#selector(panDetected(sender:)))
        self.addGestureRecognizer(PanGesture)
        
        // allows the user to manipulate the camera
        self.allowsCameraControl = false
        
        // configure the view
        self.backgroundColor = UIColor(white: 1.0, alpha: 0.5)
        
        // add a tap gesture recognizer
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        self.addGestureRecognizer(tapGesture)
        //添加3d图形
        addNode()
        //添加视图
        addScene()
//        开场动画
        delay(0.8){
            self.startAniamtion()
        }
    }
    func startAniamtion(){
        self.isUserInteractionEnabled = false
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1.5
        self.cameraOrbit.eulerAngles.x = Float(2*Double.pi)
        SCNTransaction.completionBlock = {
            self.isUserInteractionEnabled = true
        }
        SCNTransaction.commit()
    }
    func addScene(){
        if isShowModel{
            //展示test.scn的东西
            self.isUserInteractionEnabled = false
            self.scene = testScn
            self.overlaySKScene = blankScene
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            placeNode.position.x += 0.5
            placeNode.position.z += 2
            SCNTransaction.completionBlock = {
                self.isUserInteractionEnabled = true
            }
            SCNTransaction.commit()
        }else{
            if isFirstLoad{
                self.scene = self.scnScene
                self.overlaySKScene = self.textScene
                isFirstLoad = false
            }else {
                self.isUserInteractionEnabled = false
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.8
                placeNode.position.x -= 0.5
                placeNode.position.z -= 2
                //摄像头返回原来的位置
                self.lastHeightRatioTest = 0
                self.lastWidthRatioTest = 0
                self.cameraOrbitTest.eulerAngles.x = Float(-2 * Double.pi) * self.lastHeightRatioTest
                self.cameraOrbitTest.eulerAngles.y = Float(-2 * Double.pi) * self.lastWidthRatioTest
                SCNTransaction.completionBlock = {
                    self.isUserInteractionEnabled = true
                    //展示ship.scn的东西
                    self.scene = self.scnScene
                    self.overlaySKScene = self.textScene
                    //把test.scn界面的节点移除
                    self.placeNode.enumerateChildNodes { (node, stop) -> Void in
                        //                        node.removeFromParentNode()
                        if node.parent?.name == "china"{
                            node.removeFromParentNode()
                        }
                    }
                }
                SCNTransaction.commit()
            }
        }
    }
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        let p = gestureRecognize.location(in: self)
        let hitResults = self.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            if result.node.name == "top" || result.node.name == "middle" || result.node.name == "bottom"{
                if isShowModel{
                    //把test.scn界面的节点移除
                    //                placeNode.enumerateChildNodes { (node, stop) -> Void in
                    //                    node.removeFromParentNode()
                    //                }
                    isShowModel = false
                }else {
                    
                    //第四步
                    if currentNode == sphere{
                        let n = currentNode.clone()
                        placeNode.addChildNode(n)
                        n.position = SCNVector3(x:-0.5,y:0,z:-2)
                        n.rotation = SCNVector4(1, 0, 0, Double.pi/10000)
                        n.childNode(withName: "star", recursively: true)!.removeFromParentNode()
                    }else if currentNode == cylinder{
                        //第二步
                        let n = currentNode.clone()
                        placeNode.addChildNode(n)
                        n.position = SCNVector3(x:-0.5,y:0,z:-2)
                        n.rotation = SCNVector4(1, 0, 0, Double.pi/10000)
                    }else if currentNode == box{
                        //第一步
                        let n = currentNode.clone()
                        placeNode.addChildNode(n)
                        n.position = SCNVector3(x:-0.5,y:0,z:-2)
                        //                        n.rotation = SCNVector4(1, 0, 0, Double.pi/20)
                    }else if currentNode == pyramid{
                        //第三步
                        let n = currentNode.clone()
                        placeNode.addChildNode(n)
                        n.position = SCNVector3(x:-0.5,y:0,z:-2)
                        n.rotation = SCNVector4(1, 0, 0, -Double.pi/10000)
                    }
                    isShowModel = true
                }
                //更改视图
                addScene()
            }
            
        }
    }
    @objc
    func panDetected(sender: UIPanGestureRecognizer) {
        if isShowModel{
            //test.scn东西
            //控制只有绕Y轴旋转的有效
            let translation = sender.translation(in: sender.view!)
            let HeightRatio = Float(translation.y) / Float(sender.view!.frame.size.height) + lastHeightRatioTest
            let WidthRatio = Float(translation.x) / Float(sender.view!.frame.size.width) + lastWidthRatioTest
            self.cameraOrbitTest.eulerAngles.x = Float(-2 * Double.pi) * HeightRatio
            self.cameraOrbitTest.eulerAngles.y = Float(-2 * Double.pi) * WidthRatio
            if (sender.state == .ended) {
                //求余数的操作函数
                lastHeightRatioTest = HeightRatio.truncatingRemainder(dividingBy: 1)
                lastWidthRatioTest = WidthRatio.truncatingRemainder(dividingBy: 1)
            }
        }else {
            //ship.scn
            //控制只有绕Y轴旋转的有效
            let translation = sender.translation(in: sender.view!)
            let HeightRatio = Float(translation.y) / Float(sender.view!.frame.size.height) + lastHeightRatio
            self.cameraOrbit.eulerAngles.x = Float(-2 * Double.pi) * HeightRatio
            if (sender.state == .ended) {
                //求余数的操作函数
                lastHeightRatio = HeightRatio.truncatingRemainder(dividingBy: 1)
                
                //MARK: 非物体角度的reset操作
                //先处理两种特殊角度区间的情况
                if (-1.0)<=lastHeightRatio && lastHeightRatio<=(-7.0/8){
                    resetRatio = -1 - lastHeightRatio
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    SCNTransaction.completionBlock = {
                        self.lastHeightRatio = 0
                        self.resetRatio = 0
                        //显示对应的模型
                        self.showModel()
                    }
                    self.cameraOrbit.eulerAngles.x = Float(-2 * Double.pi) * (resetRatio + lastHeightRatio)
                    SCNTransaction.commit()
                }else if 7.0/8<lastHeightRatio && lastHeightRatio<=1.0{
                    resetRatio = 1 - lastHeightRatio
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    SCNTransaction.completionBlock = {
                        self.lastHeightRatio = 0
                        self.resetRatio = 0
                        //显示对应的模型
                        self.showModel()
                    }
                    self.cameraOrbit.eulerAngles.x = Float(-2 * Double.pi) * (resetRatio + lastHeightRatio)
                    SCNTransaction.commit()
                }else if -7.0/8<lastHeightRatio && lastHeightRatio<=7.0/8{
                    //处理一般情况的角度区间->角度的区间的中点为需要复原的点的角度，需要旋转的角度的算法公式是“中点角度-lastWidthRatio”
                    var minId = 0
                    var resetMid : Float = 0
                    for i in 0...(resetAngle.count-1){
                        if resetAngle[i]<lastHeightRatio && lastHeightRatio<=resetAngle[i+1]{
                            minId=i
                        }
                    }
                    //计算出复原后的点对应的角度
                    resetMid = (resetAngle[minId] + resetAngle[minId+1])/2
                    //计算应该旋转的角度
                    resetRatio = resetMid - lastHeightRatio
                    //复原的动画
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    SCNTransaction.completionBlock = {
                        self.lastHeightRatio = resetMid
                        self.resetRatio = 0
                        //显示对应的模型
                        self.showModel()
                    }
                    self.cameraOrbit.eulerAngles.x = Float(-2 * Double.pi) * (resetRatio + lastHeightRatio)
                    SCNTransaction.commit()
                }
            }
        }
    }
    
    func showModel(){
        //通过角度判断显示的模型
        root.enumerateChildNodes { (node, stop) -> Void in
            node.removeFromParentNode()
        }
        //第一步
        if lastHeightRatio == 0{
            textScene.textLabel.text = "LAPI means making \nordinary clay into a \nceramic shape,so it \nis the initial stage \nof making ceramics \nlike building a \nfoundation for the \nhouse"
            //移除粒子效果
            if isFire == true{
                fireNode.removeFromParentNode()
                //移除火焰音效
                categoryMusic.pause()
                isFire = false
            }
            //移除星星效果
            if isStar == true{
                starNode.removeFromParentNode()
                //移除火焰音效
                appearMusic.pause()
                isStar = false
            }
            currentNode = box
        }else if lastHeightRatio == 0.25 || lastHeightRatio == -0.75{
            //第四步
            textScene.textLabel.text = "Coloured drawing or \npattern means painting \non a well-fired ceramic \nmodel using different \ncolor or different\n material.This is the \nfinal stage of making \nceramic."
            //移除粒子效果
            if isFire == true{
                fireNode.removeFromParentNode()
                categoryMusic.pause()
                isFire = false
            }
            if isStar == false{
                sphere.addChildNode(starNode)
                playappearMusic(fileName:"starSound.m4a",loops:0)
                isStar = true
            }
            currentNode = sphere
        }else if lastHeightRatio == 0.5 || lastHeightRatio == -0.5{
            //第三步
            textScene.textLabel.text = "Firing means baking \na ceramic model at a \nhigh temperature of \nabout 1000-1200 \ndegrees to make ceramic \nmodel more stronger."
            //火焰的效果
            if isFire == false{
                pyramid.addChildNode(fireNode)
                playCategorySound(fileName: "fire.m4a", loops: -1)
                isFire = true
            }
            //移除星星效果
            if isStar == true{
                starNode.removeFromParentNode()
                //移除火焰音效
                appearMusic.pause()
                isStar = false
            }
            currentNode = pyramid
        }else if lastHeightRatio == 0.75 || lastHeightRatio == -0.25{
            //第二步
            textScene.textLabel.text = "Carve means drawing \npatterns with bamboo \nor iron tools on the \nsurface of the green \nbody that has not \nyet dried\n Glazed is the process \nof applying a glaze \nslurry to the surface \nof a molded ceramic body"
            //移除粒子效果
            if isFire == true{
                fireNode.removeFromParentNode()
                categoryMusic.pause()
                isFire = false
            }
            playappearMusic(fileName:"write.m4a",loops:0)
            //移除星星效果
            if isStar == true{
                starNode.removeFromParentNode()
                //移除火焰音效
                appearMusic.pause()
                isStar = false
            }
            currentNode = cylinder
        }
        print("\(lastHeightRatio)")
    }
    //MARK:addnode
    func addNode(){
        //1
        box.rotation = SCNVector4(x: 1, y: 0, z: 0, w: 0)
        box.position = SCNVector3(x:0, y: 0, z: 5)
        scnScene.rootNode.addChildNode(box)
        //2
        cylinder.rotation = SCNVector4(x: 1, y: 0, z: 0, w: 3.14159265/2)
        cylinder.position = SCNVector3(x:0, y: -5, z: 0)
        scnScene.rootNode.addChildNode(cylinder)
        //3
        pyramid.rotation = SCNVector4(x: 1, y: 0, z: 0, w: -3.14159265)
        pyramid.position = SCNVector3(x:0, y: 0, z: -5)
        scnScene.rootNode.addChildNode(pyramid)
        //4
        sphere.rotation = SCNVector4(x: 1, y: 0, z: 0, w: -3.14159265/2)
        sphere.position = SCNVector3(x:0, y: 5, z: 0)
        scnScene.rootNode.addChildNode(sphere)
    }
    //延迟函数
    func delay(_ delay:Double, closure:@escaping ()->()) {
        let when = DispatchTime.now() + delay
        DispatchQueue.main.asyncAfter(deadline: when, execute: closure)
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

