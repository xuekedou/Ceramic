/*:
 * You have already had a deep understanding of the local morphology of ceramics, and then you will learn about ceramics from another dimension——Auditory
 * [A good quality ceramic percussion sounds crisp, while a poor quality ceramic percussion sounds Dreary](glossary://A%20good%20quality%20ceramic%20percussion%20sounds%20crisp,%20while%20a%20poor%20quality%20ceramic%20percussion%20sounds%20Dreary)
 
 * Experience the sound of different parts of the same ceramic through [clicking](glossary://clicking) the different parts of the ceramic
 * Change to [different quality](glossary://different%20quality) ceramics by [code](glossary://code), experience different sounds from different quality ceramics
 * [Note](glossary://Note): For better audio performance, you can control the playing of
 background music by clicking on the horn in the upper right corner
 # Alternative models：
 * [HighQuality](glossary://HighQuality)
 * [LowQuality](glossary://LowQuality)
 
 🎉 Great! You now have a complete understanding of the ceramics from the whole to the local,
 from the visual to the auditory。The next chapter is your [showTime](glossary://showTime)！
 */
//#-hidden-code
import SceneKit
import GameplayKit
import PlaygroundSupport

let HighQuality = GameSCNView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let LowQuality = GameSCNViewOne(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, HighQuality, LowQuality)
//Change the quality of ceramics
PlaygroundPage.current.liveView =
/*#-editable-code*/HighQuality/*#-end-editable-code*/




