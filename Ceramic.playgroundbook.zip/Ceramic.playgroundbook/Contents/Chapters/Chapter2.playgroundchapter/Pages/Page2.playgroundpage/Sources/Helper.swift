//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SpriteKit
import SceneKit
import ARKit

//SKSpriteNode圆角
func SpriteCorners(preImageName : String,cornerRadius : CGFloat)->SKSpriteNode{
    let preImage = UIImage(named: preImageName)!
    //    preImage.size = CGSize(width:cornerRadius*2,height:cornerRadius*2)
    UIGraphicsBeginImageContextWithOptions(preImage.size, false, 0)
    //变成正方形
    let rect = CGRect(x: 0, y: 0, width: preImage.size.width, height: preImage.size.height)
    UIBezierPath(roundedRect: rect, cornerRadius: preImage.size.height).addClip()
    preImage.draw(in: rect)
    
    let roundImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    
    let texture = SKTexture(image: roundImage!)
    let cornerNode = SKSpriteNode(texture: texture, size: CGSize(width: cornerRadius, height: cornerRadius))
    return cornerNode
}



