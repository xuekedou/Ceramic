//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SceneKit
import SpriteKit
import PlaygroundSupport

public class GameSCNViewOne: SCNView,SCNSceneRendererDelegate {
    //存储类别的变量
    //    var currentSound : soundCategory = .wood
    var ship = SCNNode()
    var spawnTime: TimeInterval = 0
    //介绍的scene
    var textScene : GameSceneOne!
    override public init(frame: CGRect, options: [String : Any]? = nil) {
        super.init(frame: frame, options: nil)
        //初始化文字视图
        textScene = GameSceneOne(size: frame.size, scnView: self)
        self.overlaySKScene = textScene
        //背景音乐
        playBackgroundMusic(fileName:"background.m4a",loops:-1)
        // create a new scene
        let scene = SCNScene(named: "1.scn")!
        // create and add a camera to the scene
        let cameraNode = SCNNode()
        cameraNode.camera = SCNCamera()
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)
        cameraNode.camera?.fieldOfView = 20
        
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .directional
        lightNode.light?.intensity = 1150
        lightNode.position = SCNVector3(x: 0, y: 0, z: 0)
        cameraNode.addChildNode(lightNode)
        // retrieve the ship node
        ship = scene.rootNode.childNode(withName: "china", recursively: true)!
        ship.scale = SCNVector3(x: 1.5, y: 1.5, z: 1.5)
        // animate the 3d object
        ship.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 1)))
        
        // set the scene to the view
        self.scene = scene
        
        // configure the view
        self.backgroundColor = UIColor(white: 1.0, alpha: 0.5)
        
        // add a tap gesture recognizer
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        self.addGestureRecognizer(tapGesture)
    }
    func makeSound(category:soundCategory){
        switch category {
        case .wood:
            playCategorySound(fileName: "wood.m4a", loops: 1)
        case .iron:
            playCategorySound(fileName: "iron.m4a", loops: 1)
        case .stone:
            playCategorySound(fileName: "stone.m4a", loops: 1)
        }
    }
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        // check what nodes are tapped
        let p = gestureRecognize.location(in: self)
        let hitResults = self.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            if result.node.name == "top"{
                //文字
                playCategorySound(fileName: "badTop.m4a", loops: 0)
                textScene.textLabel.text = "You tap the Neck of ceramics!"
                //音效图片
                textScene.soundMake.size = CGSize(width: 22, height: 44)
                textScene.soundMake.position = CGPoint(x: textScene.size.width/2 + 40, y: textScene.size.height/4*3 - 20)
                let appear = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
                let disappear = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
                let sequence = SKAction.sequence([appear,disappear])
                textScene.soundMake.run(sequence)
            }else if result.node.name == "middle"{
                playCategorySound(fileName: "badMiddle.m4a", loops: 0)
                textScene.textLabel.text = "You tap the Abdomen of ceramics!"
                //音效图片
                textScene.soundMake.size = CGSize(width: 43, height: 88)
                textScene.soundMake.position = CGPoint(x: textScene.size.width/4*3, y: textScene.size.height/2)
                let appear = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
                let disappear = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
                let sequence = SKAction.sequence([appear,disappear])
                textScene.soundMake.run(sequence)
            }else if result.node.name == "bottom"{
                //                makeSound(category: .stone)
                playCategorySound(fileName: "badBottom.m4a", loops: 0)
                textScene.textLabel.text = "You tap the Bottom of ceramics!"
                //音效图片
                textScene.soundMake.size = CGSize(width: 22, height: 44)
                textScene.soundMake.position = CGPoint(x: textScene.size.width/2 + 50, y: textScene.size.height/4 + 30)
                let appear = SKAction.fadeAlpha(to: 1.0, duration: 1.0)
                let disappear = SKAction.fadeAlpha(to: 0.0, duration: 1.0)
                let sequence = SKAction.sequence([appear,disappear])
                textScene.soundMake.run(sequence)
            }
        }
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

