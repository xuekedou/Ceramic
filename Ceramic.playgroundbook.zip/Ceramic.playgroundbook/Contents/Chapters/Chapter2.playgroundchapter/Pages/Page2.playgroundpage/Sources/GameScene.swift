//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SpriteKit
import GameplayKit

public class GameScene : SKScene{
    public var textLabel : SKLabelNode!
    var musicSwitch : SKSpriteNode!
    var isPlayMusic : Bool = true
    var scnView : GameSCNView!
    public var soundMake : SKSpriteNode!
    init(size: CGSize,scnView : GameSCNView){
        super.init(size: size)
        //声音的介绍文字
        textLabel = SKLabelNode(text:"Tap anywhere on the ceramic")
        textLabel.numberOfLines = 0
        textLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        textLabel.fontName = "AppleSDGothicNeo-UltraLight"
        textLabel.fontSize = 15
        textLabel.fontColor = UIColor.white
        textLabel.position = CGPoint(x: size.width/2 - 20, y: size.height/5*4 + 20)
        addChild(textLabel)
        //开关音乐的按钮
        musicSwitch = SKSpriteNode(texture:SKTexture(imageNamed: "musicOn.png"), color: UIColor(white: 1.0, alpha: 0.0), size: CGSize(width: 30, height: 30))
        musicSwitch.position = CGPoint(x: size.width - 40, y: size.height/5*4 + 30)
        musicSwitch.name = "turn"
        addChild(musicSwitch)

        soundMake = SKSpriteNode(texture:SKTexture(imageNamed: "soundMake.png"), color: UIColor(white: 1.0, alpha: 0.0), size: CGSize(width: 43, height: 88))
        soundMake.position = CGPoint(x: size.width/4*3, y: size.height/2)
        soundMake.name = "soundMake"
        soundMake.alpha = 0.0
        addChild(soundMake)
        
        self.scnView = scnView
    }
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch=touches.first else{
            return
        }
        let location=touch.location(in: self)
        //开关音乐
        if self.atPoint(location).name=="turn"{
            if isPlayMusic == true{
                backgroundMusicPlayer.pause()
                musicSwitch.texture? = SKTexture(imageNamed: "musicOff.png")
                isPlayMusic = false
            }else {
                backgroundMusicPlayer.play()
                musicSwitch.texture? = SKTexture(imageNamed: "musicOn.png")
                isPlayMusic = true
            }
        }
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
