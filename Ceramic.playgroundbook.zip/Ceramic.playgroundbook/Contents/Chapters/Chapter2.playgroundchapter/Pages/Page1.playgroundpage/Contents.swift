/*:
 # In this page, you can virtually dismantle a porcelain and get the detailed information about
   every part, which will help raise awareness of every typical porcelain.
 * Through the [pinch gesture](glossary://pinch%20gesture) to dismantle the ceramic, see the ceramic local details
 * Detailed local view of the ceramic through [swipe gesture](glossary://swipe%20gesture)
 * [Tap](glossary://Tap) the part of ceramic can be more detailed, more comprehensive
   understanding of the morphology of each part of the ceramic
 * Change to different ceramic models through [code](glossary://code)
 * [Note](glossary://Note):Observing ceramics in different directions will have different
 presentations
 # Alternative models：
 * [BlueAndWhitePorcelain()](glossary://BlueAndWhitePorcelain())
 * [Square()](glossary://Square())
 * [Cylinder()](glossary://Cylinder())
 
 🎉Great! You now understand the morphological characteristics of various parts of the ceramic.
 Next you will learn more about ceramics from the [auditory dimension](glossary://auditory%20dimension)
 */
//#-hidden-code
import SceneKit
import GameplayKit
import PlaygroundSupport

let gameSCNView = GameSCNView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let gameSCNViewOne = GameSCNViewOne(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
let gameSCNViewTwo = GameSCNViewTwo(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
PlaygroundPage.current.needsIndefiniteExecution = true
func BlueAndWhitePorcelain(){
    PlaygroundPage.current.liveView = gameSCNView
}
func Square(){
    PlaygroundPage.current.liveView = gameSCNViewOne
}
func Cylinder(){
    PlaygroundPage.current.liveView = gameSCNViewTwo
}
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, BlueAndWhitePorcelain(), Square(), Cylinder())
//Change the model
//#-editable-code Remember to call function here to add model!
BlueAndWhitePorcelain()
//#-end-editable-code





