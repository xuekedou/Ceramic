//
//  GameSCNView.swift
//  CameraRotate
//
//  Created by xsf on 2018/3/14.
//  Copyright © 2018年 xsf. All rights reserved.
//
import Foundation
import SceneKit
import SpriteKit
import PlaygroundSupport

public class GameSCNView: SCNView,SCNSceneRendererDelegate {
    var lastHeightRatioTest : Float = 0
    var lastWidthRatioTest : Float = 0
    var chinaNode : SCNNode!
    var isPiece : Bool = false
    let cameraNode = SCNNode()
    let cameraOrbit = SCNNode()
    let camera = SCNCamera()
    var lastHeightRatio: Float = 0
    var hudNode : SCNNode!
    var topIntroduction : SCNNode!
    var DownIntroduction : SCNNode!
    var hudNodeMiddleTop: SCNNode!
    var hudNodeMiddleDown : SCNNode!
    var labelNode : SKLabelNode!
    var labelNodeMiddleTop : SKLabelNode!
    var labelNodeMiddleDown : SKLabelNode!
    //捏合手势
    var pinchGesture = UIPinchGestureRecognizer()
    //呈现的SCNScene
    public var scnScene = SCNScene()
    //test.scn场景
    var testScn = SCNScene()
    var placeNode = SCNNode()
    var isShowModel : Bool = false
    //test场景的镜头
    let cameraNodeTest = SCNNode()
    let cameraTest = SCNCamera()
    let cameraOrbitTest = SCNNode()
    //两个手势
    var PanGesture = UIPanGestureRecognizer()
    var tapGesture = UITapGestureRecognizer()
    //是否第一次显示
    var isFirstLoad : Bool = true
    //现在点击的部分
    var currentTapPart : String = ""
    
    override public init(frame: CGRect, options: [String : Any]? = nil) {
        super.init(frame: frame, options: nil)
        //test.scn
        testScn = SCNScene(named: "Test.scn")!
        placeNode = testScn.rootNode.childNode(withName: "place", recursively: true)!
        //render代理
        self.delegate = self
        //背景音乐
        playBackgroundMusic(fileName:"background.m4a",loops:-1)
        // create a new scene
        scnScene = SCNScene(named: "1.scn")!

        camera.fieldOfView = 25.0
        cameraNode.camera = camera
        // place the camera
        cameraNode.position = SCNVector3(x: 0.8, y: 0, z: 15)

        //旋转的轨道Node
        cameraOrbit.addChildNode(cameraNode)
        scnScene.rootNode.addChildNode(cameraOrbit)
        // create and add a light to the scene
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .directional
        lightNode.light?.intensity = 1200
        lightNode.position = SCNVector3(x: 0, y: 0, z: 0)
        cameraNode.addChildNode(lightNode)
        
        let lightNodeTest = SCNNode()
        lightNodeTest.light = SCNLight()
        lightNodeTest.light!.type = .directional
        lightNodeTest.light?.intensity = 1150
        lightNodeTest.position = SCNVector3(x: 0, y: 0, z: 0)
        cameraNodeTest.addChildNode(lightNodeTest)
        
        //test场景
        cameraNodeTest.position = SCNVector3(x: 0, y: 0, z: 3)
        cameraNodeTest.camera = cameraTest
        cameraTest.fieldOfView = 45.0
        cameraOrbitTest.addChildNode(cameraNodeTest)
        testScn.rootNode.addChildNode(cameraOrbitTest)
        
        chinaNode = scnScene.rootNode.childNode(withName: "china", recursively: true)!
        chinaNode.scale = SCNVector3(1.5, 1.5, 1.5)
        chinaNode.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 1, z: 0, duration: 1)))
        // set the scene to the view
        // add a tap gesture recognizer
        PanGesture = UIPanGestureRecognizer(target: self, action: #selector(panDetected(sender:)))
        self.addGestureRecognizer(PanGesture)

        // allows the user to manipulate the camera
        self.allowsCameraControl = false

        self.backgroundColor = UIColor(white: 1.0, alpha: 0.5)

        // add a tap gesture recognizer
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        self.addGestureRecognizer(tapGesture)
        //捏合手势
        pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchDid(_:)))
        self.addGestureRecognizer(pinchGesture)
        //添加2d文字——其实是在3d场景中
        addPanelNode()
        //添加视图
        addScene()
        //开场动画
        delay(0.8){
            self.startAniamtion()
        }
    }
    func startAniamtion(){
        self.isUserInteractionEnabled = false
        hudNode.geometry?.materials.first?.transparency = 0
        let topPart = chinaNode.childNode(withName: "top", recursively: true)
        let bottomPart = chinaNode.childNode(withName: "bottom", recursively: true)
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1.5
        self.cameraOrbit.eulerAngles.x = Float(2*Double.pi)
        topPart?.position.y += 0.7
        bottomPart?.position.y -= 0.7
        SCNTransaction.completionBlock = {
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 1.0
            topPart?.position.y -= 0.7
            bottomPart?.position.y += 0.7
            SCNTransaction.completionBlock = {
                self.isUserInteractionEnabled = true
                self.hudNode.geometry?.materials.first?.transparency = 1
            }
            SCNTransaction.commit()
        }
        SCNTransaction.commit()
    }
    func addScene(){
        if isShowModel{
            //展示test.scn的东西
            self.removeGestureRecognizer(pinchGesture)
            self.isUserInteractionEnabled = false
            self.scene = testScn
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
                if self.currentTapPart == "top"{
                    if self.isPiece == true{
                        self.placeNode.position.y -= (0.6 + 0.7)
                    }else {
                        self.placeNode.position.y -= 0.6
                    }
                }else if self.currentTapPart == "bottom"{
                    if self.isPiece == true{
                        self.placeNode.position.y += (0.6 + 0.7)
                    }else {
                        self.placeNode.position.y += 0.6
                    }
                }
                self.placeNode.position.x += 0.5
                self.placeNode.position.z += 2
                SCNTransaction.completionBlock = {
                    self.isUserInteractionEnabled = true
                }
            SCNTransaction.commit()
        }else{
            if isFirstLoad{
                self.scene = self.scnScene
                isFirstLoad = false
            }else {
                self.addGestureRecognizer(pinchGesture)
                self.isUserInteractionEnabled = false
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.8
                if currentTapPart == "top"{
                    if self.isPiece == true{
                        placeNode.position.y += (0.6 + 0.7)
                    }else{
                        placeNode.position.y += 0.6
                    }
                    
                }else if currentTapPart == "bottom"{
                    if self.isPiece == true{
                        placeNode.position.y -= (0.6 + 0.7)
                    }else{
                        placeNode.position.y -= 0.6
                    }
                }
                placeNode.position.x -= 0.5
                placeNode.position.z -= 2
                //摄像头返回原来的位置
                self.lastHeightRatioTest = 0
                self.lastWidthRatioTest = 0
                self.cameraOrbitTest.eulerAngles.x = Float(-2 * Double.pi) * self.lastHeightRatioTest
                self.cameraOrbitTest.eulerAngles.y = Float(-2 * Double.pi) * self.lastWidthRatioTest
                SCNTransaction.completionBlock = {
                    self.isUserInteractionEnabled = true
                    //展示ship.scn的东西
                    self.scene = self.scnScene
//                    self.overlaySKScene = self.textScene
                    //把test.scn界面的节点移除
                    self.placeNode.enumerateChildNodes { (node, stop) -> Void in
                        //                        node.removeFromParentNode()
                        if node.name == "top" || node.name == "middle" || node.name == "bottom"{
                            node.removeFromParentNode()
                        }
                    }
                }
                SCNTransaction.commit()
            }
        }
    }
    func addPanelNode(){
        //正面的介绍
        //中间介绍
        let skScene = SKScene(size: CGSize(width: 400, height: 400))
        skScene.backgroundColor = UIColor(white: 0.0, alpha: 0.0)
//        skScene.backgroundColor = UIColor(red:1.0,green:0,blue:0,alpha: 1.0)
        labelNode = SKLabelNode(fontNamed: "AppleSDGothicNeo-UltraLight")
        labelNode.numberOfLines = 0
        labelNode.lineBreakMode = NSLineBreakMode.byWordWrapping
        labelNode.text = "Blue and white \nporcelain is one of \nthe most famous and \nfinest types of \nceramics,which is \nrich in Jingdezhen,\nJiangxi Province, China."
        labelNode.fontColor = UIColor.black
        labelNode.fontSize = 40
        labelNode.position.y = 70
        labelNode.position.x = 200
        skScene.addChild(labelNode)
        
        let plane = SCNPlane(width: 2, height: 2)
        let material = SCNMaterial()
        material.lightingModel = SCNMaterial.LightingModel.constant
        material.isDoubleSided = true
        material.diffuse.contents = skScene
        plane.materials = [material]
        
        hudNode = SCNNode(geometry: plane)
        hudNode.name = "HUD"
        hudNode.rotation = SCNVector4(x: 1, y: 0, z: 0, w: 3.14159265)
        hudNode.position = SCNVector3(x:2, y: 0, z: 0)
        scnScene.rootNode.addChildNode(hudNode)
        hudNode.geometry?.materials.first?.transparency = 1
        //中上部分介绍
        let skSceneMiddleTop = SKScene(size: CGSize(width: 400, height: 400))
        skSceneMiddleTop.backgroundColor = UIColor(white: 0.0, alpha: 0.0)
//        skSceneMiddleTop.backgroundColor = UIColor(red:1.0,green:0,blue:0,alpha: 1.0)
        labelNodeMiddleTop = SKLabelNode(fontNamed: "AppleSDGothicNeo-UltraLight")
        labelNodeMiddleTop.numberOfLines = 0
        labelNodeMiddleTop.lineBreakMode = NSLineBreakMode.byWordWrapping
        labelNodeMiddleTop.text = ""
        labelNodeMiddleTop.fontColor = UIColor.black
        labelNodeMiddleTop.fontSize = 40
        labelNodeMiddleTop.position.y = 100
        labelNodeMiddleTop.position.x = 200
        skSceneMiddleTop.addChild(labelNodeMiddleTop)
        
        let planeMiddleTop = SCNPlane(width: 2, height: 2)
        let materialMiddleTop = SCNMaterial()
        materialMiddleTop.lightingModel = SCNMaterial.LightingModel.constant
        materialMiddleTop.isDoubleSided = true
        materialMiddleTop.diffuse.contents = skSceneMiddleTop
        planeMiddleTop.materials = [materialMiddleTop]
        
        hudNodeMiddleTop = SCNNode(geometry: planeMiddleTop)
        hudNodeMiddleTop.name = "HUDTop"
        hudNodeMiddleTop.rotation = SCNVector4(x: 1, y: 0, z: 0, w: 3.14159265)
        hudNodeMiddleTop.position = SCNVector3(x:2.0, y: 2.0, z: 0)
        scnScene.rootNode.addChildNode(hudNodeMiddleTop)
        //中下部分介绍
        let skSceneMiddleDown = SKScene(size: CGSize(width: 400, height: 400))
        skSceneMiddleDown.backgroundColor = UIColor(white: 0.0, alpha: 0.0)
        labelNodeMiddleDown = SKLabelNode(fontNamed: "AppleSDGothicNeo-UltraLight")
        labelNodeMiddleDown.numberOfLines = 0
        labelNodeMiddleDown.lineBreakMode = NSLineBreakMode.byWordWrapping
        labelNodeMiddleDown.text = ""
        labelNodeMiddleDown.fontColor = UIColor.black
        labelNodeMiddleDown.fontSize = 40
        labelNodeMiddleDown.position.y = 100
        labelNodeMiddleDown.position.x = 200
        skSceneMiddleDown.addChild(labelNodeMiddleDown)
        
        let planeMiddleDown = SCNPlane(width: 2, height: 2)
        let materialMiddleDown = SCNMaterial()
        materialMiddleDown.lightingModel = SCNMaterial.LightingModel.constant
        materialMiddleDown.isDoubleSided = true
        materialMiddleDown.diffuse.contents = skSceneMiddleDown
        planeMiddleDown.materials = [materialMiddleDown]
        
        hudNodeMiddleDown = SCNNode(geometry: planeMiddleDown)
        hudNodeMiddleDown.name = "HUDDown"
        hudNodeMiddleDown.rotation = SCNVector4(x: 1, y: 0, z: 0, w: 3.14159265)
        hudNodeMiddleDown.position = SCNVector3(x:2, y: -2.0, z: 0)
        scnScene.rootNode.addChildNode(hudNodeMiddleDown)
        
        //下面的介绍
        let skSceneDown = SKScene(size: CGSize(width: 400, height: 400))
        skSceneDown.backgroundColor = UIColor(white: 0.0, alpha: 0.0)
        let labelNodeDown = SKLabelNode(fontNamed: "AppleSDGothicNeo-UltraLight")
        labelNodeDown.numberOfLines = 0
        labelNodeDown.lineBreakMode = NSLineBreakMode.byWordWrapping
        labelNodeDown.text = "Foot:The bottom part \nof the ceramic.There \nare two main types \nof foot.\nActual:the middle \nis solid.\nCircle foot:the middle \nis empty"
        labelNodeDown.fontColor = UIColor.black
        labelNodeDown.fontSize = 40
        labelNodeDown.position.y = 0
        labelNodeDown.position.x = 210
        
        skSceneDown.addChild(labelNodeDown)
        
        let planeDown = SCNPlane(width: 2, height: 2)
        let materialDown = SCNMaterial()
        materialDown.lightingModel = SCNMaterial.LightingModel.constant
        materialDown.isDoubleSided = true
        materialDown.diffuse.contents = skSceneDown
        planeDown.materials = [materialDown]
        
        DownIntroduction = SCNNode(geometry: planeDown)
        DownIntroduction.name = "Down"
        DownIntroduction.rotation = SCNVector4(x: 1, y: 0, z: 0, w: -3.14159265/2)
        DownIntroduction.position = SCNVector3(x:1.5, y: -1, z: 0)
        scnScene.rootNode.addChildNode(DownIntroduction)
        DownIntroduction.geometry?.materials.first?.transparency = 0
        //上面的介绍
        let skSceneTop = SKScene(size: CGSize(width: 400, height: 400))
        skSceneTop.backgroundColor = UIColor(white: 0.0, alpha: 0.0)
        let labelNodeTop = SKLabelNode(fontNamed: "AppleSDGothicNeo-UltraLight")
        labelNodeTop.numberOfLines = 0
        labelNodeTop.lineBreakMode = NSLineBreakMode.byWordWrapping
        labelNodeTop.text = "Mouth section:General \nterm for the mouth \nand edges of porcelain \ncontainers"
        labelNodeTop.fontColor = UIColor.black
        labelNodeTop.fontSize = 40
        labelNodeTop.position.y = 100
        labelNodeTop.position.x = 200
        
        skSceneTop.addChild(labelNodeTop)
        
        let planeTop = SCNPlane(width: 2, height: 2)
        let materialTop = SCNMaterial()
        materialTop.lightingModel = SCNMaterial.LightingModel.constant
        materialTop.isDoubleSided = true
        materialTop.diffuse.contents = skSceneTop
        planeTop.materials = [materialTop]
        
        topIntroduction = SCNNode(geometry: planeTop)
        topIntroduction.name = "top"
        topIntroduction.rotation = SCNVector4(x: 1, y: 0, z: 0, w: 3.14159265/2)
        topIntroduction.position = SCNVector3(x:1.5, y: 1, z: 0)
        scnScene.rootNode.addChildNode(topIntroduction)
        topIntroduction.geometry?.materials.first?.transparency = 0
    }

    @objc
    func panDetected(sender: UIPanGestureRecognizer) {
        if isShowModel{
            //test.scn东西
            //控制镜头
            let translation = sender.translation(in: sender.view!)
            let HeightRatio = Float(translation.y) / Float(sender.view!.frame.size.height) + lastHeightRatioTest
            let WidthRatio = Float(translation.x) / Float(sender.view!.frame.size.width) + lastWidthRatioTest
            self.cameraOrbitTest.eulerAngles.x = Float(-2 * Double.pi) * HeightRatio
            self.cameraOrbitTest.eulerAngles.y = Float(-2 * Double.pi) * WidthRatio
            if (sender.state == .ended) {
                //求余数的操作函数
                lastHeightRatioTest = HeightRatio.truncatingRemainder(dividingBy: 1)
                lastWidthRatioTest = WidthRatio.truncatingRemainder(dividingBy: 1)
            }
        }else {
            //ship.scn
            if (sender.state == .began){
                //全部显示消失
                hudNode.geometry?.materials.first?.transparency = 0
                DownIntroduction.geometry?.materials.first?.transparency = 0
                topIntroduction.geometry?.materials.first?.transparency = 0
                labelNodeMiddleTop.text = ""
                labelNodeMiddleDown.text = ""
            }
            //控制只有绕Y轴旋转的有效
            let translation = sender.translation(in: sender.view!)
            let HeightRatio = Float(translation.y) / Float(sender.view!.frame.size.height) + lastHeightRatio
            self.cameraOrbit.eulerAngles.x = Float(-2 * Double.pi) * HeightRatio
            if (sender.state == .ended) {
                //求余数的操作函数
                lastHeightRatio = HeightRatio.truncatingRemainder(dividingBy: 1)
                //指定角度不能添加手势
                if lastHeightRatio <= -0.05 || lastHeightRatio >= 0.05{
                    self.removeGestureRecognizer(tapGesture)
                }
                //出现底部文字
                if lastHeightRatio < -0.20 && lastHeightRatio > -0.30 || lastHeightRatio < 0.80 && lastHeightRatio > 0.70{
                    DownIntroduction.geometry?.materials.first?.transparency = 1
                    //出现的音效
                    playappearMusic(fileName:"appear.m4a",loops:0)
                }else if lastHeightRatio < 0.05 && lastHeightRatio > -0.05{
                    //指定角度可以添加手势
                    self.addGestureRecognizer(tapGesture)
                    
                    hudNode.geometry?.materials.first?.transparency = 1
                    if isPiece == false{
                        labelNodeMiddleTop.text = ""
                        labelNodeMiddleDown.text = ""
                    }else {
                        labelNodeMiddleTop.text = "Neck:The transition \nbetween the mouth and \nshoulders.Because it \nresembles the neck of \na person,it gets its name."
                        labelNodeMiddleDown.text = "Bottom:play the role \nof support or sustain \nthe ceramics"
                    }
                }else if lastHeightRatio < 0.30 && lastHeightRatio > 0.20 || lastHeightRatio > -0.80 && lastHeightRatio < -0.70{
                    topIntroduction.geometry?.materials.first?.transparency = 1
                    //出现的音效
                    playappearMusic(fileName:"appear.m4a",loops:0)
                }
            }
        }
    }
    func IntroAnimation(){
        if isPiece == false{
            playCategorySound(fileName: "slice.m4a", loops: 0)
            //执行拆开动画
            let topPart = chinaNode.childNode(withName: "top", recursively: true)
            let bottomPart = chinaNode.childNode(withName: "bottom", recursively: true)
            self.isUserInteractionEnabled = false
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            topPart?.position.y += 0.7
            bottomPart?.position.y -= 0.7
            SCNTransaction.completionBlock = {
                self.isUserInteractionEnabled = true
//                self.isPiece = true
            }
            SCNTransaction.commit()
            
            //总简介编程中间部分简介
            labelNode.text = "Abdomen:The main \nholding space in the \nmiddle of the porcelain \ncontainer."
            if lastHeightRatio < 0.02 && lastHeightRatio > -0.02{
                labelNodeMiddleTop.text = "Neck:The transition \nbetween the mouth and \nshoulders.Because it \nresembles the neck of \na person,it gets its name."
                labelNodeMiddleDown.text = "Bottom:play the role \nof support or sustain \nthe ceramics"
            }
        }else{
            //复合动画
            playCategorySound(fileName: "integrate.m4a", loops: 0)
            let topPart = chinaNode.childNode(withName: "top", recursively: true)
            let bottomPart = chinaNode.childNode(withName: "bottom", recursively: true)
            self.isUserInteractionEnabled = false
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.5
            topPart?.position.y -= 0.7
            bottomPart?.position.y += 0.7
            SCNTransaction.completionBlock = {
                self.isUserInteractionEnabled = true
//                self.isPiece = true
            }
            SCNTransaction.commit()
//            isPiece = false
            //展示结束
            labelNode.text = "Blue and white \nporcelain is one of \nthe most famous and \nfinest types of \nceramics,which is \nrich in Jingdezhen,\nJiangxi Province, China."
            labelNodeMiddleTop.text = ""
            labelNodeMiddleDown.text = ""
        }
    }
    //捏合手势
    @objc func pinchDid(_ gestureRecognize: UIPinchGestureRecognizer){
        if gestureRecognize.state == .began || gestureRecognize.state == .changed{
            if gestureRecognize.scale > 1.0 && self.isPiece == false {
                //拆开的动画
                IntroAnimation()
                isPiece = true
            }else if gestureRecognize.scale < 1.0 && self.isPiece == true {
                //闭合动画
                IntroAnimation()
                isPiece = false
            }
        }
    }
    @objc
    func handleTap(_ gestureRecognize: UITapGestureRecognizer) {
        // check what nodes are tapped
        let p = gestureRecognize.location(in: self)
        let hitResults = self.hitTest(p, options: [:])
        // check that we clicked on at least one object
        if hitResults.count > 0 {
            // retrieved the first clicked object
            let result = hitResults[0]
            //只显示陶瓷的点击部分
            if result.node.name == "top" || result.node.name == "middle" || result.node.name == "bottom"{
                if isShowModel{
                    isShowModel = false
                }else {
                    //把点击的节点展示出来
                    placeNode.addChildNode(result.node.clone())
                    if result.node.name == "top"{
                        placeNode.enumerateChildNodes { (node, stop) -> Void in
                            if self.isPiece == false{
                                node.position = SCNVector3(-0.5, 0, -2)
                            }else {
                                node.position = SCNVector3(-0.5, 0.7, -2)
                            }
                            currentTapPart = "top"
                        }
                    }else if result.node.name == "middle"{
                        placeNode.enumerateChildNodes { (node, stop) -> Void in
                            node.position = SCNVector3(-0.5, 0, -2)
                            currentTapPart = "middle"
                        }
                    }else if result.node.name == "bottom"{
                        placeNode.enumerateChildNodes { (node, stop) -> Void in
                            if self.isPiece == false{
                                node.position = SCNVector3(-0.5, 0, -2)
                            }else {
                                node.position = SCNVector3(-0.5, -0.7, -2)
                            }
                            currentTapPart = "bottom"
                        }
                    }
                    isShowModel = true
                    
                }
                //点亮动画
                let material = result.node.geometry!.firstMaterial!
                // highlight it
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.5
                // on completion - unhighlight
                SCNTransaction.completionBlock = {
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    material.emission.contents = UIColor.black
                    SCNTransaction.commit()
                }
                material.emission.contents = UIColor.red
                SCNTransaction.commit()
                //更改视图
                self.addScene()
            }
        }
    }
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        
    }
    //延迟函数
    func delay(_ delay:Double, closure:@escaping ()->()) {
        let when = DispatchTime.now() + delay
        DispatchQueue.main.asyncAfter(deadline: when, execute: closure)
    }
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

